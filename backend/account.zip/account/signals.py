from django.db.models.signals import post_save
from django.dispatch import receiver
from decimal import Decimal
from .models import Transaction, Portfolio, User


@receiver(post_save, sender=Transaction)
def update_balance_and_portfolio(sender, instance, created, **kwargs):
    if not created:
        return

    user = instance.user
    qty = instance.quantity
    price = instance.price
    symbol = instance.symbol
    total = Decimal(qty) * price

    if instance.transaction_type == "BUY":
        if user.balance < total:
            raise ValueError("Insufficient funds")

        # Deduct money
        user.balance -= total
        user.save()

        # Update portfolio
        portfolio, _ = Portfolio.objects.get_or_create(user=user, symbol=symbol)
        new_qty = portfolio.quantity + qty
        if portfolio.quantity > 0:
            portfolio.avg_price = ((portfolio.quantity * portfolio.avg_price) + (qty * price)) / new_qty
        else:
            portfolio.avg_price = price
        portfolio.quantity = new_qty
        portfolio.save()

    elif instance.transaction_type == "SELL":
        portfolio = Portfolio.objects.filter(user=user, symbol=symbol).first()
        if not portfolio or portfolio.quantity < qty:
            raise ValueError("Not enough shares to sell")

        portfolio.quantity -= qty
        if portfolio.quantity == 0:
            portfolio.avg_price = Decimal(0.00)
        portfolio.save()

        # Add money
        user.balance += total
        user.save()
