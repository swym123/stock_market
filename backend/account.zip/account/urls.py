from django.urls import path,include
from .views import signup, login , profile
from .views import WatchlistViewSet
from rest_framework.routers import DefaultRouter

router = DefaultRouter()
router.register(r'watchlist', WatchlistViewSet, basename='watchlist')

urlpatterns = [
    path("signup/", signup, name="signup"),
    path("login/", login, name="login"),
    path('profile/', profile, name='profile'),
    path("", include(router.urls)),
]
