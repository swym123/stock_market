# # account/serializers.py
# from rest_framework import serializers
# from django.contrib.auth import get_user_model
# from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

# User = get_user_model()

# class UserSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = User
#         fields = ('id', 'username', 'email', 'phone')

# class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
#     def validate(self, attrs):
#         data = super().validate(attrs)
#         data.update({
#             'username': self.user.username,
#             'email': self.user.email,
#             'phone': self.user.phone,
#         })
#         return data
    
# # watchlist/serializers.py
# from rest_framework import serializers
# from .models import Watchlist

# class WatchlistSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = Watchlist
#         fields = ["id", "user", "company"]
#         read_only_fields = ["user"]  # user is automatically set from request.user


# account/serializers.py
from rest_framework import serializers
from django.contrib.auth import get_user_model, authenticate
from rest_framework_simplejwt.serializers import TokenObtainPairSerializer

User = get_user_model()


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'email', 'phone')


class CustomTokenObtainPairSerializer(TokenObtainPairSerializer):
    """
    Custom login serializer:
    - Allows login with either username OR email
    - Returns JWT tokens + user info
    """
    def validate(self, attrs):
        username_or_email = attrs.get("username")
        password = attrs.get("password")

        # First try authenticating with username
        user = authenticate(username=username_or_email, password=password)

        # If not found, try with email
        if user is None:
            try:
                email_user = User.objects.get(email=username_or_email)
                user = authenticate(username=email_user.username, password=password)
            except User.DoesNotExist:
                pass

        if user is None:
            raise serializers.ValidationError("Invalid credentials")

        refresh = self.get_token(user)

        data = {
            "refresh": str(refresh),
            "access": str(refresh.access_token),
            "username": user.username,
            "email": user.email,
            "phone": user.phone,
        }
        return data


# watchlist/serializers.py
from rest_framework import serializers
from .models import Watchlist


class WatchlistSerializer(serializers.ModelSerializer):
    class Meta:
        model = Watchlist
        fields = ["id", "user", "company"]
        read_only_fields = ["user"]  # user is automatically set from request.user
