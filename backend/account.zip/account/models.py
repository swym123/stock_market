from django.db import models
from django.contrib.auth.models import AbstractUser
from decimal import Decimal


# ✅ Custom User Model with Balance & Details
class User(AbstractUser):
    email = models.EmailField(unique=True)
    phone = models.CharField(max_length=15, unique=True, null=True, blank=True)
    balance = models.DecimalField(max_digits=15, decimal_places=2, default=100000.00)  
    # Default: 1 lakh demo money

    is_verified = models.BooleanField(default=False)
    account_type = models.CharField(
        max_length=10,
        choices=(("DEMO", "Demo"), ("LIVE", "Live")),
        default="DEMO"
    )
    risk_profile = models.CharField(
        max_length=20,
        choices=(("LOW", "Low"), ("MEDIUM", "Medium"), ("HIGH", "High")),
        default="MEDIUM"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    last_active = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.username


# ✅ Watchlist Model
class Watchlist(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="watchlists")
    name = models.CharField(max_length=100)
    symbols = models.JSONField(default=list)  # Example: ["AAPL", "TSLA", "RELIANCE.NS"]
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.name}"


# ✅ Transaction Model (Buy/Sell History)
class Transaction(models.Model):
    TRANSACTION_TYPE = (
        ("BUY", "Buy"),
        ("SELL", "Sell"),
    )
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="transactions")
    symbol = models.CharField(max_length=20)   # Stock symbol
    quantity = models.PositiveIntegerField()
    price = models.DecimalField(max_digits=12, decimal_places=2)  # per share
    transaction_type = models.CharField(max_length=4, choices=TRANSACTION_TYPE)
    date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} {self.transaction_type} {self.symbol} ({self.quantity})"


# ✅ Portfolio Model (Current Holdings)
class Portfolio(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="portfolio")
    symbol = models.CharField(max_length=20)
    quantity = models.PositiveIntegerField(default=0)
    avg_price = models.DecimalField(max_digits=12, decimal_places=2, default=0.00)

    def __str__(self):
        return f"{self.user.username} - {self.symbol} ({self.quantity})"

    @property
    def current_value(self):
        # In production, fetch live price (e.g., yfinance)
        return self.quantity * float(self.avg_price)
