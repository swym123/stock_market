// import React from 'react';
// import './Footer.css';

// const Footer = () => {
//   return (
//     <footer className="footer">
//       <div className="footer-content">
//         <div className="footer-section">
//           <h3>About Us</h3>
//           <p>We provide quality services and solutions for your needs.</p>
//         </div>
//         <div className="footer-section">
//           <h3>Quick Links</h3>
//           <ul>
//             <li><a href="/">Home</a></li>
//             <li><a href="/about">About</a></li>
//             <li><a href="/services">Services</a></li>
//             <li><a href="/contact">Contact</a></li>
//           </ul>
//         </div>
//         <div className="footer-section">
//           <h3>Contact Info</h3>
//           <p>Email: info@example.com</p>
//           <p>Phone: (123) 456-7890</p>
//         </div>
//       </div>
//       <div className="footer-bottom">
//         <p>&copy; {new Date().getFullYear()} Your Company. All rights reserved.</p>
//       </div>
//     </footer>
//   );
// };

// export default Footer;


import React from 'react';
import './Footer.css';

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-content">
        <div className="footer-section">
          <h3>Trading Platform</h3>
          <p>Your trusted partner in stock market investments. We provide cutting-edge tools and real-time data to help you make informed trading decisions.</p>
        </div>
        <div className="footer-section">
          <h3>Quick Links</h3>
          <ul>
            <li><a href="/">Home</a></li>
            <li><a href="/about">About Us</a></li>
            <li><a href="/contact">Contact</a></li>
            <li><a href="/companies">Stocks</a></li>
            <li><a href="/watchlist">Watchlist</a></li>
            <li><a href="/portfolio">Portfolio</a></li>
          </ul>
        </div>
        <div className="footer-section">
          <h3>Contact Info</h3>
          <p>Email: support@tradingplatform.com</p>
          <p>Phone: +1 (555) 123-4567</p>
          <p>Address: 123 Financial District, Mumbai, Maharashtra 400001</p>
        </div>
      </div>
      <div className="footer-bottom">
        <p>&copy; {new Date().getFullYear()} Trading Platform. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;