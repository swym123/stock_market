
import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import axios from 'axios';
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, 
  Tooltip, ResponsiveContainer, Legend
} from 'recharts';
import './CompanyInfo.css';

const CompanyInfo = () => {
  const { symbol } = useParams();
  const [stockData, setStockData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [timeframe, setTimeframe] = useState('1W');
  const [chartData, setChartData] = useState([]);
  const [userHoldings, setUserHoldings] = useState({});
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [tradeType, setTradeType] = useState('BUY');
  const [tradeQuantity, setTradeQuantity] = useState(1);
  const [tradeTotal, setTradeTotal] = useState(0);

  // Timeframe options with period and interval
  const TIME_FRAMES = [
    { label: '1D', period: '1d', interval: '15m' },
    { label: '1W', period: '7d', interval: '1d' },
    { label: '1M', period: '1mo', interval: '1d' },
    { label: '3M', period: '3mo', interval: '1d' },
    { label: '1Y', period: '1y', interval: '1wk' },
    { label: '5Y', period: '5y', interval: '3mo' }
  ];

  const getAuthHeaders = () => {
    const token = localStorage.getItem('access_token');
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  // Fetch user holdings to check if they own this stock
  useEffect(() => {
// Replace the fetchUserHoldings function with this:
const fetchUserHoldings = async () => {
  try {
    const response = await axios.get(
      "http://127.0.0.1:8000/portfolio/", // Use existing portfolio endpoint
      { headers: getAuthHeaders() }
    );
    
    if (response.data) {
      const holdings = response.data;
      const currentStockHolding = holdings.find(h => 
        h.symbol === symbol.replace('.NS','.NS').replace('.BO','.BO')
      );
      
      setUserHoldings(currentStockHolding || {});
    }
  } catch (err) {
    console.error("Error fetching user holdings:", err);
  }
};

    fetchUserHoldings();
  }, [symbol]);

  const handleTradeClick = (type) => {
    setTradeType(type);
    setTradeQuantity(1);
    setTradeTotal(stockData.currentPrice);
    setShowTradeModal(true);
  };

  const handleQuantityChange = (e) => {
    const qty = parseInt(e.target.value) || 1;
    setTradeQuantity(qty);
    setTradeTotal(qty * stockData.currentPrice);
  };

  const executeTrade = async () => {
    try {
      const transactionData = {
        symbol: symbol.replace('.NS','.NS').replace('.BO','.BO'),
        quantity: tradeQuantity,
        price: parseFloat(Number(stockData.currentPrice).toFixed(2)),
        transaction_type: tradeType
      };

      const res = await axios.post(
        "http://127.0.0.1:8000/api/account/transactions/",
        transactionData,
        { headers: getAuthHeaders() }
      );

      alert(res.data.message || `${tradeType} successful!`);
      setShowTradeModal(false);
      
      // Refresh user holdings after trade
      const response = await axios.get(
        "http://127.0.0.1:8000/api/account/holdings/",
        { headers: getAuthHeaders() }
      );
      
      if (response.data && response.data.holdings) {
        const holdings = response.data.holdings;
        const currentStockHolding = holdings.find(h => 
          h.symbol === symbol.replace('.NS','.NS').replace('.BO','.BO')
        );
        
        setUserHoldings(currentStockHolding || {});
      }
    } catch (err) {
      console.error("Trade error:", err.response?.data || err.message);
      alert(
        err.response?.data?.error ||
        err.response?.data?.message ||
        JSON.stringify(err.response?.data) ||
        "Trade failed. Please try again."
      );
    }
  };

  useEffect(() => {
    const fetchStockData = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Find selected timeframe config
        const selectedTimeframe = TIME_FRAMES.find(tf => tf.label === timeframe);
        const period = selectedTimeframe.period;
        const interval = selectedTimeframe.interval;

        // Make API call with timeframe parameters
        const response = await axios.get(
          `http://127.0.0.1:8000/api/stocks/${symbol}/`, 
          { params: { period, interval } }
        );

        const apiData = response.data.data || {};
        const history = apiData.history || [];

        // Transform data with proper fallbacks
        const transformedData = {
          symbol: apiData.symbol || symbol,
          name: apiData.companyName || apiData.longName || symbol,
          currentPrice: apiData.currentPrice || apiData.regularMarketPrice || 0,
          prevClose: apiData.previousClose || 0,
          open: apiData.open || 0,
          dayHigh: apiData.dayHigh || 0,
          dayLow: apiData.dayLow || 0,
          sector: apiData.sector || 'N/A',
          industry: apiData.industry || 'N/A',
          marketCap: apiData.marketCap || 0,
          peRatio: apiData.peRatio || apiData.trailingPE || 0,
          bookValue: apiData.bookValue || 0,
          high52Week: apiData.fiftyTwoWeekHigh || 0,
          low52Week: apiData.fiftyTwoWeekLow || 0,
          volume: apiData.volume || 0,
          avgVolume: apiData.averageVolume || 0,
          dividendYield: apiData.dividendYield || 0,
          about: apiData.longBusinessSummary || '',
          history: history
        };

        // Prepare chart data
        const formattedChartData = history.map(item => ({
          time: new Date(item.time).getTime(),
          close: item.close
        }));

        setStockData(transformedData);
        setChartData(formattedChartData);
      } catch (err) {
        console.error('API Error:', err);
        setError(err.response?.data?.message || err.message || 'Failed to fetch stock data');
      } finally {
        setLoading(false);
      }
    };

    if (symbol) {
      fetchStockData();
    } else {
      setError('No stock symbol provided');
      setLoading(false);
    }
  }, [symbol, timeframe]);

  // Calculate price change
  const getPriceChange = () => {
    if (!stockData || !stockData.prevClose) return { value: 0, percent: 0, isPositive: true };
    
    const changeValue = stockData.currentPrice - stockData.prevClose;
    const changePercent = (changeValue / stockData.prevClose) * 100;
    
    return {
      value: changeValue,
      percent: changePercent,
      isPositive: changeValue >= 0
    };
  };

  // Format large numbers
  const formatNumber = (num) => {
    if (num >= 10000000) {
      return `₹${(num / 10000000).toFixed(2)} Cr`;
    }
    if (num >= 100000) {
      return `₹${(num / 100000).toFixed(2)} L`;
    }
    return `₹${num.toLocaleString('en-IN')}`;
  };

  if (loading) {
    return (
      <div className="loading-state">
        <div className="spinner"></div>
        <p>Loading {symbol} data...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div className="error-state">
        <h3>Error Loading Data</h3>
        <p>{error}</p>
        <p>Please try again later.</p>
      </div>
    );
  }

  if (!stockData) {
    return (
      <div className="no-data">
        <p>No data available for {symbol}</p>
      </div>
    );
  }

  const priceChange = getPriceChange();
  const ownsStock = userHoldings.quantity > 0;

  return (
    <div className="company-container">
      {/* Trade Modal */}
      {showTradeModal && (
        <div className="trade-modal-overlay">
          <div className="trade-modal">
            <div className="trade-modal-header">
              <h3>{tradeType} {stockData.symbol.replace('.NS', '')}</h3>
              <button 
                className="close-modal"
                onClick={() => setShowTradeModal(false)}
              >
                &times;
              </button>
            </div>
            
            <div className="trade-modal-body">
              <div className="trade-price-info">
                <p>Current Price: ₹{stockData.currentPrice.toFixed(2)}</p>
              </div>
              
              <div className="quantity-selector">
                <label htmlFor="quantity">Quantity:</label>
                <input
                  type="number"
                  id="quantity"
                  min="1"
                  value={tradeQuantity}
                  onChange={handleQuantityChange}
                />
              </div>
              
              <div className="trade-total">
                <p>Total: ₹{tradeTotal.toFixed(2)}</p>
              </div>
            </div>
            
            <div className="trade-modal-footer">
              <button 
                className="cancel-trade"
                onClick={() => setShowTradeModal(false)}
              >
                Cancel
              </button>
              <button 
                className={`confirm-${tradeType.toLowerCase()}`}
                onClick={executeTrade}
              >
                Confirm {tradeType}
              </button>
            </div>
          </div>
        </div>
      )}

      <header className="company-header">
        <h1>
          {stockData.name}{' '}
          <span>({stockData.symbol.replace('.NS', '')})</span>
        </h1>
        
        <div className="price-display">
          <span className="current-price">
            ₹{stockData.currentPrice.toLocaleString('en-IN', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2
            })}
          </span>
          
          <span className={`price-change ${priceChange.isPositive ? 'positive' : 'negative'}`}>
            {priceChange.isPositive ? '▲' : '▼'} 
            ₹{Math.abs(priceChange.value).toFixed(2)} 
            ({Math.abs(priceChange.percent).toFixed(2)}%)
          </span>
          
          <span className="sector">{stockData.sector}</span>
        </div>
        
        <div className="industry">{stockData.industry}</div>
      </header>

      {/* Chart Section */}
      <div className="chart-section">
        <div className="chart-header">
          <h2>Price Chart</h2>
          <div className="timeframe-selector">
            {TIME_FRAMES.map((tf) => (
              <button
                key={tf.label}
                className={`timeframe-btn ${timeframe === tf.label ? 'active' : ''}`}
                onClick={() => setTimeframe(tf.label)}
              >
                {tf.label}
              </button>
            ))}
          </div>
        </div>
        
        <div className="chart-container">
          {chartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis 
                  dataKey="time"
                  type="number"
                  domain={['dataMin', 'dataMax']}
                  tickFormatter={(unixTime) => {
                    const date = new Date(unixTime);
                    if (timeframe === '1D') {
                      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
                    }
                    return date.toLocaleDateString();
                  }}
                />
                <YAxis 
                  domain={['auto', 'auto']}
                  tickFormatter={(value) => `₹${value.toFixed(2)}`}
                />
                <Tooltip
                  formatter={(value) => [`₹${value.toFixed(2)}`, 'Price']}
                  labelFormatter={(unixTime) => {
                    const date = new Date(unixTime);
                    return date.toLocaleString();
                  }}
                />
                <Legend />
                <Line
                  type="monotone"
                  dataKey="close"
                  stroke="#2962ff"
                  strokeWidth={2}
                  dot={false}
                  activeDot={{ r: 6 }}
                  name="Closing Price"
                />
              </LineChart>
            </ResponsiveContainer>
          ) : (
            <div className="no-data">
              <p>No historical data available</p>
            </div>
          )}
        </div>
      </div>

            {/* Trade Section */}
      <div className="trade-section">
        <h2>Trade {stockData.symbol.replace('.NS', '')}</h2>
        <div className="trade-actions">
          <button 
            className="buy-btn" 
            onClick={() => handleTradeClick("BUY")}
          >
            Buy
          </button>
          
          {ownsStock && (
            <button 
              className="sell-btn" 
              onClick={() => handleTradeClick("SELL")}
            >
              Sell
            </button>
          )}
        </div>
        
        {ownsStock && (
          <div className="current-holding">
            <p>You own: {userHoldings.quantity} shares</p>
            <p>Avg. price: ₹{userHoldings.average_price?.toFixed(2) || 'N/A'}</p>
          </div>
        )}
      </div>

      {/* Financial Metrics */}
      <div className="financial-metrics">
        <h2>Key Metrics</h2>
        <div className="metrics-grid">
          <div className="metric-card">
            <h3>Previous Close</h3>
            <p>₹{stockData.prevClose.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          
          <div className="metric-card">
            <h3>Open</h3>
            <p>₹{stockData.open.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          
          <div className="metric-card">
            <h3>Day's Range</h3>
            <p>₹{stockData.dayLow.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} - ₹{stockData.dayHigh.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          
          <div className="metric-card">
            <h3>Market Cap</h3>
            <p>{formatNumber(stockData.marketCap)}</p>
          </div>
          
          <div className="metric-card">
            <h3>P/E Ratio</h3>
            <p>{stockData.peRatio.toFixed(2)}</p>
          </div>
          
          <div className="metric-card">
            <h3>Book Value</h3>
            <p>₹{stockData.bookValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
          
          <div className="metric-card">
            <h3>52 Week Range</h3>
            <p>₹{stockData.low52Week.toLocaleString('en-IN')} - ₹{stockData.high52Week.toLocaleString('en-IN')}</p>
          </div>
          
          <div className="metric-card">
            <h3>Volume</h3>
            <p>{stockData.volume.toLocaleString('en-IN')}</p>
          </div>
          
          <div className="metric-card">
            <h3>Avg. Volume</h3>
            <p>{stockData.avgVolume.toLocaleString('en-IN')}</p>
          </div>
          
          {stockData.dividendYield > 0 && (
            <div className="metric-card">
              <h3>Dividend Yield</h3>
              <p>{(stockData.dividendYield * 100).toFixed(2)}%</p>
            </div>
          )}
        </div>
      </div>



      {stockData.about && (
        <div className="company-description">
          <h2>About the Company</h2>
          <p>{stockData.about}</p>
        </div>
      )}
    </div>
  );
};

export default CompanyInfo;