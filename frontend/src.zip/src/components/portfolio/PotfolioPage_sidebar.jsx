
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './Portfolio.css';
import Sidebar from '../Sidebar/Sidebar';

const Portfolio = () => {
  const [holdings, setHoldings] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('holdings');
  const [nextPage, setNextPage] = useState(null);
  const [prevPage, setPrevPage] = useState(null);
  const [totalProfitLoss, setTotalProfitLoss] = useState(0);
  const [totalInvestment, setTotalInvestment] = useState(0);
  const [totalCurrentValue, setTotalCurrentValue] = useState(0);
  const navigate = useNavigate();

  const getAuthHeaders = () => {
    const token = localStorage.getItem('access_token');
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  const fetchHoldings = async () => {
    try {
      const response = await axios.get(
        'http://127.0.0.1:8000/api/account/portfolio/',
        { headers: getAuthHeaders() }
      );
      const holdingsData = Array.isArray(response.data.results) ? response.data.results : response.data;
      setHoldings(holdingsData);
      
      const investment = holdingsData.reduce(
        (sum, holding) => sum + (holding.avg_price * holding.quantity), 0
      );

      const currentValue = holdingsData.reduce(
        (sum, holding) => sum + (holding.current_price * holding.quantity), 0
      );

      const profitLoss = currentValue - investment;

      setTotalInvestment(investment);
      setTotalCurrentValue(currentValue);
      setTotalProfitLoss(profitLoss);
      
    } catch (error) {
      console.error('Error fetching holdings:', error);
      if (error.response?.status === 401) navigate('/login');
    }
  };

  const fetchTransactions = async (url = 'http://127.0.0.1:8000/api/account/transactions/history/') => {
    try {
      setLoading(true);
      const response = await axios.get(url, { headers: getAuthHeaders() });
      setTransactions(response.data.results);
      setNextPage(response.data.next);
      setPrevPage(response.data.previous);
    } catch (error) {
      console.error('Error fetching transactions:', error);
      if (error.response?.status === 401) navigate('/login');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHoldings();
    fetchTransactions();
  }, []);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('en-IN', {
      style: 'currency',
      currency: 'INR'
    }).format(value);
  };

  const formatDate = (dateString) => new Date(dateString).toLocaleString();

  return (
    <div className="app-container">
      <Sidebar />
      <div className="portfolio-container">
        <h1>My Portfolio</h1>

        <div className="summary-section">
          <div className="summary-card">
            <h3>Total Investment</h3>
            <p>{formatCurrency(totalInvestment)}</p>
          </div>
          <div className="summary-card">
            <h3>Current Value</h3>
            <p>{formatCurrency(totalCurrentValue)}</p>
          </div>
          <div className={`summary-card ${totalProfitLoss >= 0 ? 'profit' : 'loss'}`}>
            <h3>Profit/Loss</h3>
            <p>
              {formatCurrency(totalProfitLoss)} 
              {totalProfitLoss !== 0 && (
                <span className="percentage">
                  ({((totalProfitLoss / totalInvestment) * 100).toFixed(2)}%)
                </span>
              )}
            </p>
          </div>
        </div>

        <div className="tabs">
          <button
            className={activeTab === 'holdings' ? 'active' : ''}
            onClick={() => setActiveTab('holdings')}
          >
            Current Holdings
          </button>
          <button
            className={activeTab === 'history' ? 'active' : ''}
            onClick={() => setActiveTab('history')}
          >
            Transaction History
          </button>
        </div>

        {activeTab === 'holdings' ? (
          <div className="holdings-section">
            <h2>Current Holdings</h2>
            {holdings.length > 0 ? (
              <>
                <table className="holdings-table">
                  <thead>
                    <tr>
                      <th>Symbol</th>
                      <th>Company</th>
                      <th>Shares</th>
                      <th>Avg Price</th>
                      <th>Current Price</th>
                      <th>Investment</th>
                      <th>Current Value</th>
                      <th>P&L</th>
                    </tr>
                  </thead>
                  <tbody>
                    {holdings.map((holding) => {
                      const investment = holding.avg_price * holding.quantity;
                      const currentValue = holding.current_price * holding.quantity;
                      const profitLoss = currentValue - investment;
                      const profitLossPercentage = investment > 0 ? (profitLoss / investment) * 100 : 0;
                      
                      return (
                        <tr key={holding.symbol}>
                          <td>{holding.symbol}</td>
                          <td>{holding.company_name}</td>
                          <td>{holding.quantity}</td>
                          <td>{formatCurrency(holding.avg_price)}</td>
                          <td>{formatCurrency(holding.current_price)}</td>
                          <td>{formatCurrency(investment)}</td>
                          <td>{formatCurrency(currentValue)}</td>
                          <td className={profitLoss >= 0 ? 'profit' : 'loss'}>
                            {formatCurrency(profitLoss)}
                            <br />
                            <span className="percentage">
                              {profitLossPercentage.toFixed(2)}%
                            </span>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </>
            ) : (
              <p>You don't have any holdings yet.</p>
            )}
          </div>
        ) : (
          <div className="history-section">
            <h2>Transaction History</h2>
            {transactions.length > 0 ? (
              <>
                <table className="history-table">
                  <thead>
                    <tr>
                      <th>Date</th>
                      <th>Type</th>
                      <th>Symbol</th>
                      <th>Shares</th>
                      <th>Price</th>
                      <th>Total</th>
                    </tr>
                  </thead>
                  <tbody>
                    {transactions.map((txn) => (
                      <tr key={txn.id} className={txn.transaction_type.toLowerCase()}>
                        <td>{formatDate(txn.date)}</td>
                        <td>{txn.transaction_type}</td>
                        <td>{txn.symbol}</td>
                        <td>{txn.quantity}</td>
                        <td>{formatCurrency(txn.price)}</td>
                        <td>{formatCurrency(txn.quantity * txn.price)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>

                <div className="pagination">
                  {prevPage && <button onClick={() => fetchTransactions(prevPage)}>Previous</button>}
                  {nextPage && <button onClick={() => fetchTransactions(nextPage)}>Next</button>}
                </div>
              </>
            ) : (
              <p>No transactions found.</p>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default Portfolio;