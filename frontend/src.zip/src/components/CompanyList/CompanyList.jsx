
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import "./CompanyList.css";

// const CompanyList = () => {
//   const [companies, setCompanies] = useState([]);
//   const [nextPage, setNextPage] = useState(null);
//   const [prevPage, setPrevPage] = useState(null);
//   const [loading, setLoading] = useState(false);
//   const [watchlistSymbols, setWatchlistSymbols] = useState([]);

//   const getAuthHeaders = () => {
//     const token = localStorage.getItem("access_token");
//     return token ? { Authorization: `Bearer ${token}` } : {};
//   };

//   // Fetch companies without caching
//   const fetchCompanies = async (url = "http://127.0.0.1:8000/api/companies/") => {
//     try {
//       setLoading(true);
//       const res = await axios.get(url, { headers: getAuthHeaders() });
//       setCompanies(res.data.results);
//       setNextPage(res.data.next);
//       setPrevPage(res.data.previous);
//     } catch (error) {
//       console.error("Error fetching companies:", error);
//       if (error.response?.status === 401) {
//         alert("Session expired. Please log in again.");
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch user's watchlist symbols
//   const fetchWatchlistSymbols = async () => {
//     try {
//       const res = await axios.get(
//         "http://127.0.0.1:8000/api/account/watchlist/check/",
//         { headers: getAuthHeaders() }
//       );
//       setWatchlistSymbols(res.data.symbols);
//     } catch (error) {
//       console.error("Error fetching watchlist:", error);
//     }
//   };

//   // Add to watchlist
//   const addToWatchlist = async (symbol, companyName) => {
//     try {
//       await axios.post(
//         "http://127.0.0.1:8000/api/account/watchlist/",
//         { 
//           name: companyName,
//           symbols: [symbol]
//         },
//         { headers: getAuthHeaders() }
//       );

//       setWatchlistSymbols(prev => [...prev, symbol]);
//       alert(`(${symbol}) added to watchlist!`);
//     } catch (error) {
//       console.error("Error adding to watchlist:", error);
//       if (error.response?.status === 401) {
//         alert("Please log in to add to watchlist.");
//       } else if (error.response?.data?.error) {
//         alert(error.response.data.error);
//       } else {
//         alert("Failed to add to watchlist. Please try again.");
//       }
//     }
//   };

//   // Buy stock
//   const buyStock = async (symbol, price) => {
//     try {
//       const quantity = prompt(`Enter quantity to buy for ${symbol} (Current price: $${price})`, "1");
//       if (!quantity || isNaN(quantity)) return;

//       await axios.post(
//         "http://127.0.0.1:8000/api/account/transactions/",
//         {
//           symbol: symbol,
//           quantity: parseInt(quantity),
//           price: price,
//           transaction_type: "BUY"
//         },
//         { headers: getAuthHeaders() }
//       );

//       alert(`Successfully bought ${quantity} shares of ${symbol} at $${price} each!`);
//     } catch (error) {
//       console.error("Error buying stock:", error);
//       if (error.response?.status === 401) {
//         alert("Please log in to buy stocks.");
//       } else if (error.response?.data?.error) {
//         alert(error.response.data.error);
//       } else {
//         alert("Failed to complete purchase. Please try again.");
//       }
//     }
//   };

//   useEffect(() => {
//     fetchCompanies();
//     fetchWatchlistSymbols();
//   }, []);

//   return (
//     <div className="company-container">
//       <h1 className="company-title">Company List</h1>

//       {loading ? (
//         <p>Loading...</p>
//       ) : (
//         <table className="company-table">
//           <thead>
//             <tr>
//               <th>ID</th>
//               <th>Name</th>
//               <th>Symbol</th>
//               <th>Price</th>
//               <th>Change %</th>
//               <th>Watchlist</th>
//               <th>Trade</th>
//             </tr>
//           </thead>
//           <tbody>
//             {companies.map((company) => (
//               <tr key={company.id}>
//                 <td>{company.id}</td>
//                 <td>{company.name}</td>
//                 <td>{company.tradingsymbol}</td>
//                 <td>{company.current_price ?? "—"}</td>
//                 <td className={company.day_change_percent > 0 ? "price-up" : "price-down"}>
//                   {company.day_change_percent ?? "—"}%
//                 </td>
//                 <td>
//                   {watchlistSymbols.includes(company.tradingsymbol) ? (
//                     <span className="added-badge">⭐ Added</span>
//                   ) : (
//                     <button 
//                       onClick={() => addToWatchlist(company.tradingsymbol, company.name)}
//                       className="add-button"
//                     >
//                       Add to Watchlist
//                     </button>
//                   )}
//                 </td>
//                 <td>
//                   <button 
//                     onClick={() => buyStock(company.tradingsymbol, company.current_price)}
//                     className="add-button"
//                     style={{ backgroundColor: "#2196F3" }}
//                   >
//                     Buy
//                   </button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       <div className="pagination">
//         <button onClick={() => fetchCompanies(prevPage)} disabled={!prevPage}>
//           Previous
//         </button>
//         <button onClick={() => fetchCompanies(nextPage)} disabled={!nextPage}>
//           Next
//         </button>
//       </div>
//     </div>
//   );
// };

// export default CompanyList;
import React, { useEffect, useState } from "react";
import axios from "axios";
import "./CompanyList.css";

const CompanyList = () => {
  const [companies, setCompanies] = useState([]);
  const [nextPage, setNextPage] = useState(null);
  const [prevPage, setPrevPage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [watchlistSymbols, setWatchlistSymbols] = useState([]);
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [currentStock, setCurrentStock] = useState(null);
  const [tradeQuantity, setTradeQuantity] = useState(1);
  const [buying, setBuying] = useState(false);

  const getAuthHeaders = () => {
    const token = localStorage.getItem("access_token");
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  // Fetch companies without caching
  const fetchCompanies = async (url = "http://127.0.0.1:8000/api/companies/") => {
    try {
      setLoading(true);
      const res = await axios.get(url, { headers: getAuthHeaders() });
      setCompanies(res.data.results);
      setNextPage(res.data.next);
      setPrevPage(res.data.previous);
    } catch (error) {
      console.error("Error fetching companies:", error);
      if (error.response?.status === 401) {
        alert("Session expired. Please log in again.");
      }
    } finally {
      setLoading(false);
    }
  };

  // Fetch user's watchlist symbols
  const fetchWatchlistSymbols = async () => {
    try {
      const res = await axios.get(
        "http://127.0.0.1:8000/api/account/watchlist/check/",
        { headers: getAuthHeaders() }
      );
      setWatchlistSymbols(res.data.symbols);
    } catch (error) {
      console.error("Error fetching watchlist:", error);
    }
  };

  // Add to watchlist
  const addToWatchlist = async (symbol, companyName) => {
    try {
      await axios.post(
        "http://127.0.0.1:8000/api/account/watchlist/",
        { 
          name: companyName,
          symbols: [symbol]
        },
        { headers: getAuthHeaders() }
      );

      setWatchlistSymbols(prev => [...prev, symbol]);
      alert(`(${symbol}) added to watchlist!`);
    } catch (error) {
      console.error("Error adding to watchlist:", error);
      if (error.response?.status === 401) {
        alert("Please log in to add to watchlist.");
      } else if (error.response?.data?.error) {
        alert(error.response.data.error);
      } else {
        alert("Failed to add to watchlist. Please try again.");
      }
    }
  };

  // Handle buy button click
  const handleBuyClick = (company, e) => {
    e.stopPropagation();
    setCurrentStock({
      symbol: company.tradingsymbol,
      name: company.name,
      price: company.current_price || 0
    });
    setTradeQuantity(1);
    setShowTradeModal(true);
  };

  // Execute buy transaction
  const executeBuy = async () => {
    try {
      setBuying(true);

      // Create transaction
      const transactionData = {
        symbol: currentStock.symbol,
        quantity: tradeQuantity,
        price: parseFloat(Number(currentStock.price).toFixed(2)),
        transaction_type: "BUY"
      };

      const res = await axios.post(
        "http://127.0.0.1:8000/api/account/transactions/",
        transactionData,
        { headers: getAuthHeaders() }
      );

      alert(res.data.message || "Purchase successful!");
      setShowTradeModal(false);

    } catch (error) {
      console.error("Error buying stock:", error.response?.data || error.message);

      alert(
        error.response?.data?.error ||
        error.response?.data?.message ||
        JSON.stringify(error.response?.data) ||
        "Failed to complete purchase. Please try again."
      );
    } finally {
      setBuying(false);
    }
  };

  // Handle quantity change
  const handleQuantityChange = (e) => {
    const qty = parseInt(e.target.value) || 1;
    setTradeQuantity(qty);
  };

  useEffect(() => {
    fetchCompanies();
    fetchWatchlistSymbols();
  }, []);

  return (
    <div className="company-container">
      <h1 className="company-title">Company List</h1>

      {loading ? (
        <p>Loading...</p>
      ) : (
        <table className="company-table">
          <thead>
            <tr>
              <th>ID</th>
              <th>Name</th>
              <th>Symbol</th>
              <th>Price</th>
              <th>Change %</th>
              <th>Watchlist</th>
              <th>Trade</th>
            </tr>
          </thead>
          <tbody>
            {companies.map((company) => (
              <tr key={company.id}>
                <td>{company.id}</td>
                <td>{company.name}</td>
                <td>{company.tradingsymbol}</td>
                <td>{company.current_price ?? "—"}</td>
                <td className={company.day_change_percent > 0 ? "price-up" : "price-down"}>
                  {company.day_change_percent ?? "—"}%
                </td>
                <td>
                  {watchlistSymbols.includes(company.tradingsymbol) ? (
                    <span className="added-badge">⭐ Added</span>
                  ) : (
                    <button 
                      onClick={() => addToWatchlist(company.tradingsymbol, company.name)}
                      className="add-button"
                    >
                      Add to Watchlist
                    </button>
                  )}
                </td>
                <td>
                  <button 
                    onClick={(e) => handleBuyClick(company, e)}
                    className="add-button"
                    style={{ backgroundColor: "#2196F3" }}
                  >
                    Buy
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      <div className="pagination">
        <button onClick={() => fetchCompanies(prevPage)} disabled={!prevPage}>
          Previous
        </button>
        <button onClick={() => fetchCompanies(nextPage)} disabled={!nextPage}>
          Next
        </button>
      </div>

      {/* Trade Modal */}
      {showTradeModal && currentStock && (
        <div className="trade-modal-overlay">
          <div className="trade-modal">
            <div className="trade-modal-header">
              <h3>BUY {currentStock.symbol}</h3>
              <button 
                className="close-modal"
                onClick={() => setShowTradeModal(false)}
              >
                &times;
              </button>
            </div>
            
            <div className="trade-modal-body">
              <div className="trade-price-info">
                <p>Company: {currentStock.name}</p>
                <p>Current Price: ₹{currentStock.price.toFixed(2)}</p>
              </div>
              
              <div className="quantity-selector">
                <label htmlFor="quantity">Quantity:</label>
                <input
                  type="number"
                  id="quantity"
                  min="1"
                  value={tradeQuantity}
                  onChange={handleQuantityChange}
                />
              </div>
              
              <div className="trade-total">
                <p>Total: ₹{(currentStock.price * tradeQuantity).toFixed(2)}</p>
              </div>
            </div>
            
            <div className="trade-modal-footer">
              <button 
                className="cancel-trade"
                onClick={() => setShowTradeModal(false)}
              >
                Cancel
              </button>
              <button 
                className="confirm-buy"
                onClick={executeBuy}
                disabled={buying}
              >
                {buying ? "Processing..." : "Confirm BUY"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default CompanyList;