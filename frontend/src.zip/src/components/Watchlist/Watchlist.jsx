

// import "./Watchlist.css";
// import React, { useEffect, useState } from "react";
// import axios from "axios";
// import { Link, useNavigate } from "react-router-dom";


// const WatchlistPage = () => {
//   const [watchlist, setWatchlist] = useState([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState(null);
//   const [prices, setPrices] = useState({});
//   const [buying, setBuying] = useState({});
//   const [showModal, setShowModal] = useState(false);
//   const [currentStock, setCurrentStock] = useState(null);
//   const navigate = useNavigate();

//   const getAuthHeaders = () => {
//     const token = localStorage.getItem("access_token");
//     return token ? { Authorization: `Bearer ${token}` } : {};
//   };

//   // Helper function to convert NSE symbol to Yahoo Finance format
//   const toYahooSymbol = (symbol) => {
//     if (!symbol.endsWith('.NS')) {
//       return symbol + '.NS';
//     }
//     return symbol;
//   };

//   // Helper function to convert Yahoo symbol back to NSE format
//   const toNseSymbol = (symbol) => {
//     if (symbol.endsWith('.NS')) {
//       return symbol.replace('.NS', '');
//     }
//     return symbol;
//   };

//   // Fetch user's watchlist
//   const fetchWatchlist = async () => {
//     try {
//       setLoading(true);
//       const res = await axios.get(
//         "http://127.0.0.1:8000/api/account/watchlist/",
//         { headers: getAuthHeaders() }
//       );
      
//       console.log("API Response:", res.data);

//       let items = [];
      
//       if (Array.isArray(res.data)) {
//         items = res.data;
//       } else if (res.data && Array.isArray(res.data.results)) {
//         items = res.data.results;
//       } else if (res.data && res.data.watchlist) {
//         items = res.data.watchlist;
//       } else if (res.data && typeof res.data === 'object') {
//         items = [res.data];
//       }

//       const formattedItems = items.map(item => ({
//         id: item.id || '',
//         symbol: Array.isArray(item.symbols) && item.symbols.length > 0 ? toNseSymbol(item.symbols[0]) : '',
//         name: item.name || '',
//         current_price: item.current_price || 0,
//         change_percent: item.change_percent || 0,
//       }));

//       setWatchlist(formattedItems);
      
//       // Fetch prices for all symbols
//       if (formattedItems.length > 0) {
//         const symbols = formattedItems.map(item => toYahooSymbol(item.symbol));
//         fetchPrices(symbols);
//       }
//     } catch (error) {
//       console.error("Error fetching watchlist:", error);
//       setError(error.response?.data?.message || "Failed to load watchlist. Please try again.");
//       if (error.response?.status === 401) {
//         navigate("/login");
//       }
//     } finally {
//       setLoading(false);
//     }
//   };

//   // Fetch current prices
//   const fetchPrices = async (symbols) => {
//     try {
//       const res = await axios.post(
//         "http://127.0.0.1:8000/api/account/watchlist/prices/",
//         { symbols },
//         { headers: getAuthHeaders() }
//       );
      
//       if (res.data && res.data.prices) {
//         // Convert Yahoo symbols back to NSE format for display
//         const nsePrices = {};
//         Object.keys(res.data.prices).forEach(yahooSymbol => {
//           const nseSymbol = toNseSymbol(yahooSymbol);
//           nsePrices[nseSymbol] = res.data.prices[yahooSymbol];
//         });
//         setPrices(nsePrices);
//       }
//     } catch (error) {
//       console.error("Error fetching prices:", error);
//     }
//   };

//   // Handle buy action
//   const handleBuy = async (symbol) => {
//     try {
//       setBuying(prev => ({ ...prev, [symbol]: true }));

//       // Always buy 1 share
//       const quantity = 1;

//       // Convert to Yahoo symbol for price lookup
//       const yahooSymbol = toYahooSymbol(symbol);

//       // Get current price
//       let currentPrice = 0;
//       if (prices[symbol]) {
//         currentPrice = prices[symbol];
//       } else {
//         try {
//           const priceRes = await axios.post(
//             "http://127.0.0.1:8000/api/account/watchlist/prices/",
//             { symbols: [yahooSymbol] },
//             { headers: getAuthHeaders() }
//           );

//           if (priceRes.data?.prices?.[yahooSymbol]) {
//             currentPrice = priceRes.data.prices[yahooSymbol];
//           }
//         } catch (priceError) {
//           console.error("Error fetching current price:", priceError);
//           alert("Could not fetch current price. Please try again.");
//           return;
//         }
//       }

//       // Ensure price is a valid decimal (2 digits)
//       const roundedPrice = parseFloat(Number(currentPrice).toFixed(2));

//       // Create transaction
//       const transactionData = {
//         symbol: symbol,
//         quantity: quantity,
//         price: roundedPrice,
//         transaction_type: "BUY"
//       };

//       const res = await axios.post(
//         "http://127.0.0.1:8000/api/account/transactions/",
//         transactionData,
//         { headers: getAuthHeaders() }
//       );

//       // Show confirmation modal
//       setCurrentStock({
//         symbol: symbol,
//         price: roundedPrice,
//         quantity: quantity,
//         total: roundedPrice * quantity
//       });
//       setShowModal(true);

//       // Refresh the user's balance and portfolio
//       fetchWatchlist();

//     } catch (error) {
//       console.error("Error buying stock:", error.response?.data || error.message);

//       alert(
//         error.response?.data?.error ||
//         error.response?.data?.message ||
//         JSON.stringify(error.response?.data) ||
//         "Failed to complete purchase. Please try again."
//       );
//     } finally {
//       setBuying(prev => ({ ...prev, [symbol]: false }));
//     }
//   };

//   // Remove from watchlist
//   const removeFromWatchlist = async (id, e) => {
//     e.stopPropagation();
//     try {
//       await axios.delete(
//         `http://127.0.0.1:8000/api/account/watchlist/${id}/`,
//         { headers: getAuthHeaders() }
//       );
//       setWatchlist(prev => prev.filter(item => item.id !== id));
//       alert("Successfully removed from watchlist");
//     } catch (error) {
//       console.error("Error removing from watchlist:", error);
//       alert(error.response?.data?.message || "Failed to remove from watchlist. Please try again.");
//     }
//   };

//   useEffect(() => {
//     fetchWatchlist();
//   }, []);

//   if (loading) {
//     return <div className="watchlist-container">Loading your watchlist...</div>;
//   }

//   if (error) {
//     return <div className="watchlist-container error">{error}</div>;
//   }

//   return (
//     <div className="watchlist-container">
//       <h1 className="watchlist-title">My Watchlist</h1>
      
//       {watchlist.length === 0 ? (
//         <p className="empty-watchlist">Your watchlist is empty. Add some stocks from the company list!</p>
//       ) : (
//         <table className="watchlist-table">
//           <thead>
//             <tr>
//               <th>Symbol</th>
//               <th>Company Name</th>
//               <th>Current Price (₹)</th>
//               <th>Change %</th>
//               <th>Actions</th>
//             </tr>
//           </thead>
//           <tbody>
//             {watchlist.map((item) => (
//               <tr 
//                 key={item.id} 
//                 onClick={() => navigate(`/stock/${item.symbol}`)}
//                 style={{ cursor: "pointer" }}
//               >
//                 <td>{item.symbol}</td>
//                 <td>{item.name}</td>
//                 <td>
//                   {prices[item.symbol] ? (
//                     `₹${prices[item.symbol].toFixed(2)}`
//                   ) : (
//                     "Loading..."
//                   )}
//                 </td>
//                 <td className={item.change_percent >= 0 ? "positive" : "negative"}>
//                   {item.change_percent.toFixed(2)}%
//                 </td>
//                 <td>
//                   <button 
//                     onClick={(e) => {
//                       e.stopPropagation();
//                       handleBuy(item.symbol);
//                     }}
//                     className="buy-button"
//                     disabled={buying[item.symbol] || !prices[item.symbol]}
//                   >
//                     {buying[item.symbol] ? "Processing..." : "Buy"}
//                   </button>
//                   <button 
//                     onClick={(e) => removeFromWatchlist(item.id, e)}
//                     className="remove-button"
//                   >
//                     Remove
//                   </button>
//                 </td>
//               </tr>
//             ))}
//           </tbody>
//         </table>
//       )}

//       {/* Confirmation Modal */}
//       {showModal && currentStock && (
//         <div className="modal-overlay">
//           <div className="modal-content">
//             <div className="modal-header">
//               <h2>BUY {currentStock.symbol}</h2>
//             </div>
//             <div className="modal-body">
//               <p className="current-price">Current Price: ₹{currentStock.price.toFixed(2)}</p>
//               <div className="total-section">
//                 <h3>Total: ₹{currentStock.total.toFixed(2)}</h3>
//               </div>
//               <p className="transaction-time">{new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
//             </div>
//             <div className="modal-actions">
//               <button 
//                 className="cancel-btn"
//                 onClick={() => setShowModal(false)}
//               >
//                 Cancel
//               </button>
//               <button 
//                 className="confirm-btn"
//                 onClick={() => {
//                   setShowModal(false);
//                   alert("Purchase confirmed!");
//                 }}
//               >
//                 Confirm BUY
//               </button>
//             </div>
//           </div>
//         </div>
//       )}
//     </div>
//   );
// };

// export default WatchlistPage;

import "./Watchlist.css";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link, useNavigate } from "react-router-dom";

const WatchlistPage = () => {
  const [watchlist, setWatchlist] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [prices, setPrices] = useState({});
  const [buying, setBuying] = useState({});
  const [showTradeModal, setShowTradeModal] = useState(false);
  const [currentStock, setCurrentStock] = useState(null);
  const [tradeQuantity, setTradeQuantity] = useState(1);
  const navigate = useNavigate();

  const getAuthHeaders = () => {
    const token = localStorage.getItem("access_token");
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  // Helper function to convert NSE symbol to Yahoo Finance format
  const toYahooSymbol = (symbol) => {
    if (!symbol.endsWith('.NS')) {
      return symbol + '.NS';
    }
    return symbol;
  };

  // Helper function to convert Yahoo symbol back to NSE format
  const toNseSymbol = (symbol) => {

    return symbol;
  };

  // Fetch user's watchlist
  const fetchWatchlist = async () => {
    try {
      setLoading(true);
      const res = await axios.get(
        "http://127.0.0.1:8000/api/account/watchlist/",
        { headers: getAuthHeaders() }
      );
      
      console.log("API Response:", res.data);

      let items = [];
      
      if (Array.isArray(res.data)) {
        items = res.data;
      } else if (res.data && Array.isArray(res.data.results)) {
        items = res.data.results;
      } else if (res.data && res.data.watchlist) {
        items = res.data.watchlist;
      } else if (res.data && typeof res.data === 'object') {
        items = [res.data];
      }

      const formattedItems = items.map(item => ({
        id: item.id || '',
        symbol: Array.isArray(item.symbols) && item.symbols.length > 0 ? toNseSymbol(item.symbols[0]) : '',
        name: item.name || '',
        current_price: item.current_price || 0,
        change_percent: item.change_percent || 0,
      }));

      



      setWatchlist(formattedItems);
      
      // Fetch prices for all symbols
      if (formattedItems.length > 0) {
        const symbols = formattedItems.map(item => toYahooSymbol(item.symbol));
        fetchPrices(symbols);
      }
    } catch (error) {
      console.error("Error fetching watchlist:", error);
      setError(error.response?.data?.message || "Failed to load watchlist. Please try again.");
      if (error.response?.status === 401) {
        navigate("/login");
      }
    } finally {
      setLoading(false);
    }
  };

  // Fetch current prices
  const fetchPrices = async (symbols) => {
    try {
      const res = await axios.post(
        "http://127.0.0.1:8000/api/account/watchlist/prices/",
        { symbols },
        { headers: getAuthHeaders() }
      );
      
      if (res.data && res.data.prices) {
        // Convert Yahoo symbols back to NSE format for display
        const nsePrices = {};
        Object.keys(res.data.prices).forEach(yahooSymbol => {
          const nseSymbol = toNseSymbol(yahooSymbol);
          nsePrices[nseSymbol] = res.data.prices[yahooSymbol];
        });
        setPrices(nsePrices);
      }
    } catch (error) {
      console.error("Error fetching prices:", error);
    }
  };

  // Handle buy button click
  const handleBuyClick = (stock, e) => {
    e.stopPropagation();
    setCurrentStock({
      id: stock.id,
      symbol: stock.symbol,
      name: stock.name,
      price: prices[stock.symbol] || 0
    });
    setTradeQuantity(1);
    setShowTradeModal(true);
  };

  // Execute buy transaction
  const executeBuy = async () => {
    try {
      setBuying(prev => ({ ...prev, [currentStock.symbol]: true }));

      // Create transaction
      const transactionData = {
        symbol: currentStock.symbol,
        quantity: tradeQuantity,
        price: parseFloat(Number(currentStock.price).toFixed(2)),
        transaction_type: "BUY"
      };

      const res = await axios.post(
        "http://127.0.0.1:8000/api/account/transactions/",
        transactionData,
        { headers: getAuthHeaders() }
      );

      alert(res.data.message || "Purchase successful!");
      setShowTradeModal(false);

      // Refresh the user's balance and portfolio
      fetchWatchlist();

    } catch (error) {
      console.error("Error buying stock:", error.response?.data || error.message);

      alert(
        error.response?.data?.error ||
        error.response?.data?.message ||
        JSON.stringify(error.response?.data) ||
        "Failed to complete purchase. Please try again."
      );
    } finally {
      setBuying(prev => ({ ...prev, [currentStock.symbol]: false }));
    }
  };

  // Handle quantity change
  const handleQuantityChange = (e) => {
    const qty = parseInt(e.target.value) || 1;
    setTradeQuantity(qty);
  };

  // Remove from watchlist
  const removeFromWatchlist = async (id, e) => {
    e.stopPropagation();
    try {
      await axios.delete(
        `http://127.0.0.1:8000/api/account/watchlist/${id}/`,
        { headers: getAuthHeaders() }
      );
      setWatchlist(prev => prev.filter(item => item.id !== id));
      alert("Successfully removed from watchlist");
    } catch (error) {
      console.error("Error removing from watchlist:", error);
      alert(error.response?.data?.message || "Failed to remove from watchlist. Please try again.");
    }
  };

  useEffect(() => {
    fetchWatchlist();
  }, []);

  if (loading) {
    return <div className="watchlist-container">Loading your watchlist...</div>;
  }

  if (error) {
    return <div className="watchlist-container error">{error}</div>;
  }

  return (
    <div className="watchlist-container">
      <h1 className="watchlist-title">My Watchlist</h1>
      
      {watchlist.length === 0 ? (
        <p className="empty-watchlist">Your watchlist is empty. Add some stocks from the company list!</p>
      ) : (
        <table className="watchlist-table">
          <thead>
            <tr>
              <th>Symbol</th>
              <th>Company Name</th>
              <th>Current Price (₹)</th>
              <th>Change %</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {watchlist.map((item) => (
              <tr 
                key={item.id} 
                onClick={() => navigate(`/stock/${item.symbol}`)}
                style={{ cursor: "pointer" }}
              >
                <td>{item.symbol}</td>
                <td>{item.name}</td>
                <td>
                  {prices[item.symbol] ? (
                    `₹${prices[item.symbol].toFixed(2)}`
                  ) : (
                    "Loading..."
                  )}
                </td>
                <td className={item.change_percent >= 0 ? "positive" : "negative"}>
                  {item.change_percent.toFixed(2)}%
                </td>
                <td>
                  <button 
                    onClick={(e) => handleBuyClick(item, e)}
                    className="buy-button"
                    disabled={!prices[item.symbol]}
                  >
                    Buy
                  </button>
                  <button 
                    onClick={(e) => removeFromWatchlist(item.id, e)}
                    className="remove-button"
                  >
                    Remove
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {/* Trade Modal */}
      {showTradeModal && currentStock && (
        <div className="trade-modal-overlay">
          <div className="trade-modal">
            <div className="trade-modal-header">
              <h3>BUY {currentStock.symbol}</h3>
              <button 
                className="close-modal"
                onClick={() => setShowTradeModal(false)}
              >
                &times;
              </button>
            </div>
            
            <div className="trade-modal-body">
              <div className="trade-price-info">
                <p>Current Price: ₹{currentStock.price.toFixed(2)}</p>
              </div>
              
              <div className="quantity-selector">
                <label htmlFor="quantity">Quantity:</label>
                <input
                  type="number"
                  id="quantity"
                  min="1"
                  value={tradeQuantity}
                  onChange={handleQuantityChange}
                />
              </div>
              
              <div className="trade-total">
                <p>Total: ₹{(currentStock.price * tradeQuantity).toFixed(2)}</p>
              </div>
            </div>
            
            <div className="trade-modal-footer">
              <button 
                className="cancel-trade"
                onClick={() => setShowTradeModal(false)}
              >
                Cancel
              </button>
              <button 
                className="confirm-buy"
                onClick={executeBuy}
                disabled={buying[currentStock.symbol]}
              >
                {buying[currentStock.symbol] ? "Processing..." : "Confirm BUY"}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default WatchlistPage;