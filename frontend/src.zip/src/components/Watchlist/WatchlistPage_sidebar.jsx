

import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Watchlist.css";
import Sidebar from '../Sidebar/Sidebar';

const WatchlistPage = () => {
  const [watchlist, setWatchlist] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const navigate = useNavigate();

  const getAuthHeaders = () => {
    const token = localStorage.getItem("access_token");
    return token ? { Authorization: `Bearer ${token}` } : {};
  };

  const fetchWatchlist = async () => {
    try {
      setLoading(true);
      const res = await axios.get(
        "http://127.0.0.1:8000/api/account/watchlist/",
        { headers: getAuthHeaders() }
      );
      
      let items = [];
      
      if (Array.isArray(res.data)) {
        items = res.data;
      } else if (res.data && Array.isArray(res.data.results)) {
        items = res.data.results;
      } else if (res.data && res.data.watchlist) {
        items = res.data.watchlist;
      } else if (res.data && typeof res.data === 'object') {
        items = [res.data];
      }

      const formattedItems = items.map(item => ({
        id: item.id || '',
        symbol: Array.isArray(item.symbols) && item.symbols.length > 0 ? item.symbols[0] : '',
        name: item.name || '',
        current_price: item.current_price || 0,
        day_change_percent: item.day_change_percent || 0,
      }));

      setWatchlist(formattedItems);
    } catch (error) {
      console.error("Error fetching watchlist:", error);
      setError(error.response?.data?.message || "Failed to load watchlist. Please try again.");
      if (error.response?.status === 401) {
        navigate("/login");
      }
    } finally {
      setLoading(false);
    }
  };

  const removeFromWatchlist = async (id) => {
    try {
      await axios.delete(
        `http://127.0.0.1:8000/api/account/watchlist/${id}/`,
        { headers: getAuthHeaders() }
      );
      setWatchlist(prev => prev.filter(item => item.id !== id));
      alert("Successfully removed from watchlist");
    } catch (error) {
      console.error("Error removing from watchlist:", error);
      alert(error.response?.data?.message || "Failed to remove from watchlist. Please try again.");
    }
  };

  useEffect(() => {
    fetchWatchlist();
  }, []);

  if (loading) {
    return (
      <div className="app-container">
        <Sidebar />
        <div className="watchlist-container">Loading your watchlist...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="app-container">
        <Sidebar />
        <div className="watchlist-container error">{error}</div>
      </div>
    );
  }

  return (
    <div className="app-container">
      <Sidebar />
      <div className="watchlist-container">
        <h1 className="watchlist-title">My Watchlist</h1>
        
        {watchlist.length === 0 ? (
          <p className="empty-watchlist">Your watchlist is empty. Add some stocks from the company list!</p>
        ) : (
          <table className="watchlist-table">
            <thead>
              <tr>
                <th>Symbol</th>
                <th>Company Name</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {watchlist.map((item) => (
                <tr 
                  key={item.id} 
                  onClick={() => navigate(`/stock/${item.symbol}`)}
                  style={{ cursor: "pointer" }}
                >
                  <td>{item.symbol}</td>
                  <td>{item.name}</td>
                  <td>
                    <button 
                      onClick={(e) => {
                        e.stopPropagation();
                        removeFromWatchlist(item.id);
                      }}
                      className="remove-button"
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
};

export default WatchlistPage;