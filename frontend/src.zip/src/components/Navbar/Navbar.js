import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Navbar.css';
import { getProfile } from "../../api";

const Navbar = () => {
  // Search state
  const [searchQuery, setSearchQuery] = useState('');
  const [suggestions, setSuggestions] = useState([]);
  const [showSuggestions, setShowSuggestions] = useState(false);

  // Auth state
  const [showAuthModal, setShowAuthModal] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [authData, setAuthData] = useState({
    name: '',
    email: '',
    password: '',
  });
  const [user, setUser] = useState(() => {
    const savedUser = localStorage.getItem("user");
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [authError, setAuthError] = useState('');

  // Search suggestions
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (searchQuery.length > 1) {
        try {
          const response = await axios.get(
            'http://127.0.0.1:8000/api/search/',
            { params: { q: searchQuery } }
          );
          setSuggestions(response.data);
          setShowSuggestions(true);
        } catch (error) {
          console.error('Error fetching suggestions:', error);
        }
      } else {
        setSuggestions([]);
        setShowSuggestions(false);
      }
    };

    const timer = setTimeout(() => {
      fetchSuggestions();
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  const handleAuthChange = (e) => {
    setAuthData({ ...authData, [e.target.name]: e.target.value });
    setAuthError('');
  };

  const handleAuthSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isLogin) {
        
        const response = await axios.post('http://127.0.0.1:8000/api/account/login/', {
          username: authData.name,
          password: authData.password,
        });

        if (response.data.error) {
          throw new Error(response.data.error);
        }

        localStorage.setItem('access_token', response.data.tokens.access);
        localStorage.setItem('refresh_token', response.data.tokens.refresh);
        
        // Fetch user profile after login
        const profile = await getProfile();
        const userData = {
          username: profile.username,
          email: profile.email,
          phone: profile.phone || null
        };
        
        setUser(userData);
        localStorage.setItem("user", JSON.stringify(userData));
        localStorage.setItem("userProfile", JSON.stringify(userData));

        setShowAuthModal(false);
        setAuthData({ name: '', email: '', password: '' });
      } else {
        const response = await axios.post('http://127.0.0.1:8000/api/account/signup/', {
          username: authData.name,
          email: authData.email,
          password: authData.password,
        });

        if (response.data.error) {
          throw new Error(response.data.error);
        }

        localStorage.setItem('access_token', response.data.tokens.access);
        localStorage.setItem('refresh_token', response.data.tokens.refresh);
        
        const userData = {
          username: response.data.user.username,
          email: response.data.user.email,
          phone: response.data.user.phone || null
        };
        
        setUser(userData);
        localStorage.setItem("user", JSON.stringify(userData));
        localStorage.setItem("userProfile", JSON.stringify(userData));

        setShowAuthModal(false);
        setAuthData({ name: '', email: '', password: '' });
      }
    } catch (error) {
      let errorMessage = error.response?.data?.error || 
                        error.message || 
                        'Authentication failed. Please try again.';
      
      setAuthError(errorMessage);
    }
  };

  const handleLogout = async () => {
    try {
      await axios.post('http://127.0.0.1:8000/api/account/logout/', {
        refresh_token: localStorage.getItem('refresh_token'),
      }, {
        headers: {
          Authorization: `Bearer ${localStorage.getItem('access_token')}`
        }
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      localStorage.removeItem('access_token');
      localStorage.removeItem('refresh_token');
      localStorage.removeItem('user');
      localStorage.removeItem('userProfile');
      setUser(null);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();

    const matched = suggestions.find(
      (company) => company.tradingsymbol.toLowerCase() === searchQuery.toLowerCase()
    );

    if (matched) {
      window.location.href = `/stock/${matched.tradingsymbol}`;
    } else if (suggestions.length > 0) {
      const first = suggestions[0];
      setSearchQuery(first.tradingsymbol);
      window.location.href = `/stock/${first.tradingsymbol}`;
    } else {
      console.log("No valid suggestion found. Not searching.");
    }

    setShowSuggestions(false);
  };

  const handleSuggestionClick = (company) => {
    setSearchQuery(company.tradingsymbol);
    setShowSuggestions(false);
    window.location.href = `/stock/${company.tradingsymbol}`;
  };

  return (
    <nav className="navbar">
      <div className="navbar-container">
        <div className="navbar-brand">
          <span className="brand-text">StockMarket</span>
        </div>

        <div className="search-container">
          <form onSubmit={handleSearch} className="search-form">
            <div className="search-input-wrapper">
              <input
                type="text"
                placeholder="Search companies..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => searchQuery.length > 1 && setShowSuggestions(true)}
                onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
                className="search-input"
              />
              <button type="submit" className="search-button">Search</button>
            </div>

            {showSuggestions && suggestions.length > 0 && (
              <div className="suggestions-dropdown">
                {suggestions.map((company) => (
                  <a
                    key={company.id}
                    href={`/stock/${company.tradingsymbol}`}
                    style={{ textDecoration: 'none' }}
                  >
                    <div
                      className="suggestion-item"
                      onClick={() => handleSuggestionClick(company)}
                    >
                      <span className="symbol">{company.tradingsymbol}</span>
                      <span className="name">{company.name}</span>
                    </div>
                  </a>
                ))}
              </div>
            )}
          </form>
        </div>

        <div className="navbar-links">
          <a href="/" className="nav-link">Home</a>
          <a href="/companies" className="nav-link">Stocks</a>
          <a href="/watchlist" className="nav-link">Watchlist</a>
          <a href="/portfolio" className="nav-link">Portfolio</a>

          {user ? (
            <div className="user-dropdown">
              <button className="user-button">
                <img
                  src={'/default-avatar.png'}
                  alt={user.username}
                  className="user-avatar"
                />
                <span className="username">{user.username}</span>
              </button>
              <div className="dropdown-menu">
                <a href="/profile" className="dropdown-item">Profile</a>
                <button onClick={handleLogout} className="dropdown-item">Logout</button>
              </div>
            </div>
          ) : (
            <button
              className="auth-button"
              onClick={() => {
                setShowAuthModal(true);
                setIsLogin(true);
                setAuthError('');
              }}
            >
              Login
            </button>
          )}
        </div>
      </div>

      {showAuthModal && (
        <div className="auth-modal">
          <div className="auth-modal-content">
            <button
              className="close-button"
              onClick={() => {
                setShowAuthModal(false);
                setAuthError('');
              }}
            >
              &times;
            </button>

            <h2 className="auth-title">{isLogin ? 'Login' : 'Sign Up'}</h2>

            {authError && <div className="auth-error">{authError}</div>}

            <form onSubmit={handleAuthSubmit} className="auth-form">
              <div className="form-group">
                <label htmlFor="name" className="form-label">Username</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={authData.name}
                  onChange={handleAuthChange}
                  required
                  className="form-input"
                />
              </div>

              {!isLogin && (
                <div className="form-group">
                  <label htmlFor="email" className="form-label">Email</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={authData.email}
                    onChange={handleAuthChange}
                    required
                    className="form-input"
                  />
                </div>
              )}

              <div className="form-group">
                <label htmlFor="password" className="form-label">Password</label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  value={authData.password}
                  onChange={handleAuthChange}
                  required
                  className="form-input"
                  minLength="4"
                />
              </div>

              <button type="submit" className="auth-submit-button">
                {isLogin ? 'Login' : 'Sign Up'}
              </button>
            </form>

            <div className="auth-switch">
              {isLogin ? (
                <p className="switch-text">
                  Don't have an account?{' '}
                  <button
                    onClick={() => {
                      setIsLogin(false);
                      setAuthError('');
                    }}
                    className="switch-button"
                  >
                    Sign Up
                  </button>
                </p>
              ) : (
                <p className="switch-text">
                  Already have an account?{' '}
                  <button
                    onClick={() => {
                      setIsLogin(true);
                      setAuthError('');
                    }}
                    className="switch-button"
                  >
                    Login
                  </button>
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;