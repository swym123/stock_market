import React, { useState, useEffect } from 'react';
import './Home.css';

const Home = () => {
  const [news, setNews] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchNews();
  }, []);

  const fetchNews = async (query = '') => {
    setLoading(true);
    try {
      const response = await fetch(`http://localhost:8000/api/news/?q=${query}`);
      const data = await response.json();
      setNews(data);
    } catch (error) {
      console.error('Error fetching news:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = (e) => {
    e.preventDefault();
    if (searchTerm.trim()) {
      fetchNews(searchTerm);
    } else {
      fetchNews();
    }
  };

  return (
    <main className="home-container">
      <section className="home-hero">
        <h1 className="home-hero__title">Indian Stock Market News</h1>
        <p className="home-hero__subtitle">Get the latest updates on NSE/BSE listed companies</p>
        <form onSubmit={handleSearch} className="home-search">
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search company (e.g. TCS, NIFTY)"
            className="home-search__input"
          />
          <button type="submit" className="home-search__button">
            Search
          </button>
        </form>
      </section>
      
      <section className="home-news">
        <h2 className="home-news__title">
          {searchTerm ? `News about ${searchTerm.toUpperCase()}` : 'Latest Market News'}
        </h2>
        {loading ? (
          <p className="home-news__loading">Loading news...</p>
        ) : (
          <div className="home-news__grid">
            {news.length > 0 ? (
              news.map((item, index) => (
                <div className="home-news__card" key={index}>
                  {item.image && <img src={item.image} alt={item.title} className="home-news__image" />}
                  <h3 className="home-news__card-title">{item.title}</h3>
                  <p className="home-news__card-description">{item.description}</p>
                  <a href={item.link} target="_blank" rel="noopener noreferrer" className="home-news__link">
                    Read More
                  </a>
                  <p className="home-news__date">{item.published}</p>
                </div>
              ))
            ) : (
              <p className="home-news__empty">No news found. Try searching for a different company.</p>
            )}
          </div>
        )}
      </section>
    </main>
  );
};

export default Home;