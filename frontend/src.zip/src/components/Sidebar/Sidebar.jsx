import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import './Sidebar.css';

const Sidebar = () => {
  const navigate = useNavigate();
  
  const handleLogout = () => {
    localStorage.removeItem('access_token');
    localStorage.removeItem('user');
    navigate('/');
  };

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <h2>Trading Platform</h2>
      </div>
      
      <nav className="sidebar-nav">
        <ul>
              <li>
            <NavLink to="/profile" activeclassname="active">
              <i className="icon profile"></i>
              Profile
            </NavLink>
          </li>

          <li>
            <NavLink to="/portfolio_sidebar" activeclassname="active">
              <i className="icon portfolio"></i>
              Portfolio
            </NavLink>
          </li>
                    <li>
            <NavLink to="/watchlis_sidebart" activeclassname="active">
              <i className="icon watchlist"></i>
              Watchlist
            </NavLink>
          </li>
        </ul>
      </nav>
      
      <div className="sidebar-footer">
        <button onClick={handleLogout} className="logout-btn">
          <i className="icon logout"></i>
          Logout
        </button>
      </div>
    </div>
  );
};

export default Sidebar;