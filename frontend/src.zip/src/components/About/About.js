import React from 'react';
import './About.css';

const About = () => {
  return (
    <div className="about-container">
      <h1>About Our Trading Platform</h1>
      <div className="about-content">
        <section className="about-section">
          <h2>Our Mission</h2>
          <p>
            We aim to democratize stock trading by providing a user-friendly platform 
            that empowers both beginners and experienced traders with real-time market data, 
            advanced analytics, and seamless trading experience.
          </p>
        </section>

        <section className="about-section">
          <h2>What We Offer</h2>
          <div className="features-grid">
            <div className="feature-card">
              <h3>Real-time Data</h3>
              <p>Access live market data and stock prices with minimal latency.</p>
            </div>
            <div className="feature-card">
              <h3>Portfolio Tracking</h3>
              <p>Monitor your investments and track performance in real-time.</p>
            </div>
            <div className="feature-card">
              <h3>Watchlists</h3>
              <p>Create personalized watchlists to track your favorite stocks.</p>
            </div>
            <div className="feature-card">
              <h3>Secure Trading</h3>
              <p>Execute trades with confidence using our secure platform.</p>
            </div>
          </div>
        </section>

        <section className="about-section">
          <h2>Our Team</h2>
          <p>
            Our team consists of experienced financial experts, developers, and designers 
            who are passionate about creating the best trading experience for our users.
          </p>
        </section>
      </div>
    </div>
  );
};

export default About;