// DataLoader.js (frontend component)
import React from 'react';
import { CircularProgressbar } from 'react-circular-progressbar';
import 'react-circular-progressbar/dist/styles.css';

const DataLoader = ({ user }) => {
  // Calculate completion percentage
  const calculateCompletion = () => {
    let completedFields = 0;
    const totalFields = 7; // Adjust based on your fields
    
    if (user.username) completedFields++;
    if (user.email) completedFields++;
    if (user.phone) completedFields++;
    if (user.account_type) completedFields++;
    if (user.risk_profile) completedFields++;
    if (user.watchlists && user.watchlists.length > 0) completedFields++;
    if (user.portfolio && user.portfolio.length > 0) completedFields++;
    
    return Math.round((completedFields / totalFields) * 100);
  };

  return (
    <div style={{ width: '100px', margin: '20px auto' }}>
      <CircularProgressbar 
        value={calculateCompletion()} 
        text={`${calculateCompletion()}%`} 
      />
      <p style={{ textAlign: 'center', marginTop: '10px' }}>Profile Complete</p>
    </div>
  );
};

export default DataLoader;