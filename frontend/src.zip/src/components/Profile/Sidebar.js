// Sidebar.js (frontend component)
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { List, ListItem, ListItemIcon, ListItemText } from '@material-ui/core';
import {
  AccountCircle as ProfileIcon,
  List as WatchlistIcon,
  Assessment as PortfolioIcon,
  Settings as SettingsIcon,
  ExitToApp as LogoutIcon
} from '@material-ui/icons';

const Sidebar = () => {
  const location = useLocation();

  return (
    <div style={{ width: '250px', height: '100vh', background: '#f5f5f5' }}>
      <List>
        <ListItem 
          button 
          component={Link} 
          to="/profile" 
          selected={location.pathname === '/profile'}
        >
          <ListItemIcon><ProfileIcon /></ListItemIcon>
          <ListItemText primary="Profile" />
        </ListItem>
        <ListItem 
          button 
          component={Link} 
          to="/watchlist" 
          selected={location.pathname === '/watchlist'}
        >
          <ListItemIcon><WatchlistIcon /></ListItemIcon>
          <ListItemText primary="Watchlist" />
        </ListItem>
        <ListItem 
          button 
          component={Link} 
          to="/portfolio" 
          selected={location.pathname === '/portfolio'}
        >
          <ListItemIcon><PortfolioIcon /></ListItemIcon>
          <ListItemText primary="Portfolio" />
        </ListItem>
        <ListItem 
          button 
          component={Link} 
          to="/settings" 
          selected={location.pathname === '/settings'}
        >
          <ListItemIcon><SettingsIcon /></ListItemIcon>
          <ListItemText primary="Settings" />
        </ListItem>
        <ListItem button onClick={() => {/* handle logout */}}>
          <ListItemIcon><LogoutIcon /></ListItemIcon>
          <ListItemText primary="Logout" />
        </ListItem>
      </List>
    </div>
  );
};

export default Sidebar;