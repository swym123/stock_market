// import React, { useState, useEffect } from 'react';
// import './Profile.css';
// import { useNavigate } from 'react-router-dom';

// const ProfilePage = () => {
//   const navigate = useNavigate();
//   const [userData, setUserData] = useState(() => {
//     // Initialize from localStorage if available
//     const savedUser = localStorage.getItem('user');
//     return savedUser 
//       ? JSON.parse(savedUser)
//       : {
//           username: '',
//           email: '',
//           phone: '',
//           account_type: 'DEMO',
//           risk_profile: 'MEDIUM',
//           balance: '0.00'
//         };
//   });
  
//   const [isLoading, setIsLoading] = useState(true);
//   const [error, setError] = useState('');
//   const [successMessage, setSuccessMessage] = useState('');

//   const updateLocalStorageUser = (userData) => {
//     localStorage.setItem('user', JSON.stringify({
//       username: userData.username,
//       email: userData.email,
//       phone: userData.phone,
//       account_type: userData.account_type,
//       risk_profile: userData.risk_profile,
//       balance: userData.balance
//     }));
//   };

//   const fetchProfile = async () => {
//     setIsLoading(true);
//     setError('');
    
//     try {
//       const token = localStorage.getItem('access_token');
//       if (!token) {
//         throw new Error('Authentication token not found. Please log in again.');
//       }

//       const response = await fetch('http://localhost:8000/api/account/profile/', {
//         method: 'GET',
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//           'Accept': 'application/json'
//         },
//         credentials: 'include'
//       });

//       if (response.status === 401) {
//         localStorage.removeItem('access_token');
//         localStorage.removeItem('user');
//         navigate('/login');
//         return;
//       }

//       if (!response.ok) {
//         const errorData = await response.json().catch(() => ({}));
//         throw new Error(
//           errorData.detail || 
//           errorData.message || 
//           `Server responded with status ${response.status}`
//         );
//       }

//       const data = await response.json();
//       const updatedUserData = {
//         username: data.username || '',
//         email: data.email || '',
//         phone: data.phone || '',
//         account_type: data.account_type || 'DEMO',
//         risk_profile: data.risk_profile || 'MEDIUM',
//         balance: data.balance || '0.00'
//       };
      
//       setUserData(updatedUserData);
//       updateLocalStorageUser(updatedUserData);
      
//     } catch (error) {
//       console.error('Fetch profile error:', error);
//       setError(error.message || 'Failed to fetch profile data');
//     } finally {
//       setIsLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchProfile();
//   }, []);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setUserData(prev => ({
//       ...prev,
//       [name]: value
//     }));
//   };

//   const handleSubmit = async (e) => {
//     e.preventDefault();
//     setError('');
//     setSuccessMessage('');
    
//     try {
//       const token = localStorage.getItem('access_token');
//       if (!token) {
//         throw new Error('Authentication token not found. Please log in again.');
//       }

//       const response = await fetch('http://localhost:8000/api/account/profile/', {
//         method: 'PUT',
//         headers: {
//           'Authorization': `Bearer ${token}`,
//           'Content-Type': 'application/json',
//           'Accept': 'application/json'
//         },
//         credentials: 'include',
//         body: JSON.stringify({
//           username: userData.username,
//           email: userData.email,
//           phone: userData.phone,
//           account_type: userData.account_type,
//           risk_profile: userData.risk_profile
//         })
//       });

//       if (response.status === 401) {
//         localStorage.removeItem('access_token');
//         localStorage.removeItem('user');
//         navigate('/login');
//         return;
//       }

//       if (!response.ok) {
//         const errorData = await response.json().catch(() => ({}));
//         throw new Error(
//           errorData.detail || 
//           errorData.message || 
//           `Server responded with status ${response.status}`
//         );
//       }

//       const data = await response.json();
//       const updatedUserData = {
//         username: data.username || userData.username,
//         email: data.email || userData.email,
//         phone: data.phone || userData.phone,
//         account_type: data.account_type || userData.account_type,
//         risk_profile: data.risk_profile || userData.risk_profile,
//         balance: data.balance || userData.balance
//       };
      
//       setUserData(updatedUserData);
//       updateLocalStorageUser(updatedUserData);
//       setSuccessMessage('Profile updated successfully!');
      
//     } catch (error) {
//       console.error('Update profile error:', error);
//       setError(error.message || 'Failed to update profile');
//     }
//   };

//   if (isLoading) {
//     return (
//       <div className="profile-container">
//         <div className="loading-spinner"></div>
//         <p>Loading profile...</p>
//       </div>
//     );
//   }

//   return (
//     <div className="profile-container">
//       <h1>Your Profile</h1>
      
//       <div className="profile-header">
//         <div className="avatar-placeholder">
//           {userData.username ? userData.username.charAt(0).toUpperCase() : 'U'}
//         </div>
//         <h2>{userData.username}</h2>
//       </div>
      
//       {error && <div className="message error">{error}</div>}
//       {successMessage && <div className="message success">{successMessage}</div>}
      
//       <form onSubmit={handleSubmit}>
//         <div className="form-group">
//           <label htmlFor="username">Username</label>
//           <input
//             type="text"
//             id="username"
//             name="username"
//             value={userData.username}
//             onChange={handleChange}
//             required
//           />
//         </div>
        
//         <div className="form-group">
//           <label htmlFor="email">Email</label>
//           <input
//             type="email"
//             id="email"
//             name="email"
//             value={userData.email}
//             onChange={handleChange}
//             required
//           />
//         </div>
        
//         <div className="form-group">
//           <label htmlFor="phone">Phone</label>
//           <input
//             type="tel"
//             id="phone"
//             name="phone"
//             value={userData.phone}
//             onChange={handleChange}
//           />
//         </div>
        
//         <div className="form-group">
//           <label htmlFor="account_type">Account Type</label>
//           <select
//             id="account_type"
//             name="account_type"
//             value={userData.account_type}
//             onChange={handleChange}
//           >
//             <option value="DEMO">Demo Account</option>
//             <option value="LIVE">Live Account</option>
//           </select>
//         </div>
        
//         <div className="form-group">
//           <label htmlFor="risk_profile">Risk Profile</label>
//           <select
//             id="risk_profile"
//             name="risk_profile"
//             value={userData.risk_profile}
//             onChange={handleChange}
//           >
//             <option value="LOW">Low Risk</option>
//             <option value="MEDIUM">Medium Risk</option>
//             <option value="HIGH">High Risk</option>
//           </select>
//         </div>
        
//         <div className="balance-group">
//           <label>Account Balance</label>
//           <div className="balance-amount">${parseFloat(userData.balance).toFixed(2)}</div>
//         </div>
        
//         <div className="form-actions">
//           <button type="submit" className="btn-update">Update Profile</button>
//         </div>
//       </form>
//     </div>
//   );
// };

// export default ProfilePage;


import React, { useState, useEffect } from 'react';
import './Profile.css';
import { useNavigate } from 'react-router-dom';
import Sidebar from '../Sidebar/Sidebar';

const ProfilePage = () => {
  const navigate = useNavigate();
  const [userData, setUserData] = useState(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser 
      ? JSON.parse(savedUser)
      : {
          username: '',
          email: '',
          phone: '',
          account_type: 'DEMO',
          risk_profile: 'MEDIUM',
          balance: '0.00'
        };
  });
  
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [addFundsAmount, setAddFundsAmount] = useState('');
  const [isAddingFunds, setIsAddingFunds] = useState(false);
  const [formErrors, setFormErrors] = useState({});

  const updateLocalStorageUser = (userData) => {
    localStorage.setItem('user', JSON.stringify({
      username: userData.username,
      email: userData.email,
      phone: userData.phone,
      account_type: userData.account_type,
      risk_profile: userData.risk_profile,
      balance: userData.balance
    }));
  };

  const fetchProfile = async () => {
    setIsLoading(true);
    setError('');
    
    try {
      const token = localStorage.getItem('access_token');
      if (!token) {
        throw new Error('Authentication token not found. Please log in again.');
      }

      const response = await fetch('http://localhost:8000/api/account/profile/', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include'
      });

      if (response.status === 401) {
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        navigate('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.detail || 
          errorData.message || 
          `Server responded with status ${response.status}`
        );
      }

      const data = await response.json();
      const updatedUserData = {
        username: data.username || '',
        email: data.email || '',
        phone: data.phone || '',
        account_type: data.account_type || 'DEMO',
        risk_profile: data.risk_profile || 'MEDIUM',
        balance: data.balance || '0.00'
      };
      
      setUserData(updatedUserData);
      updateLocalStorageUser(updatedUserData);
      
    } catch (error) {
      console.error('Fetch profile error:', error);
      setError(error.message || 'Failed to fetch profile data');
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchProfile();
  }, []);

  const validateProfile = () => {
    const errors = {};
    
    if (!userData.username || userData.username.length < 3) {
      errors.username = 'Username must be at least 3 characters';
    }
    
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(userData.email)) {
      errors.email = 'Please enter a valid email address';
    }
    
    if (userData.phone && userData.phone.length < 10) {
      errors.phone = 'Phone number must be at least 10 digits';
    }
    
    return errors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setUserData(prev => ({
      ...prev,
      [name]: value
    }));
    
    // Clear error when user types
    if (formErrors[name]) {
      setFormErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMessage('');
    
    const errors = validateProfile();
    if (Object.keys(errors).length > 0) {
      setFormErrors(errors);
      setError('Please fix the form errors');
      return;
    }
    
    try {
      const token = localStorage.getItem('access_token');
      if (!token) {
        throw new Error('Authentication token not found. Please log in again.');
      }

      const response = await fetch('http://localhost:8000/api/account/profile/', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        credentials: 'include',
        body: JSON.stringify({
          username: userData.username,
          email: userData.email,
          phone: userData.phone,
          account_type: userData.account_type,
          risk_profile: userData.risk_profile
        })
      });

      if (response.status === 401) {
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        navigate('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.detail || 
          errorData.message || 
          `Server responded with status ${response.status}`
        );
      }

      const data = await response.json();
      const updatedUserData = {
        username: data.username || userData.username,
        email: data.email || userData.email,
        phone: data.phone || userData.phone,
        account_type: data.account_type || userData.account_type,
        risk_profile: data.risk_profile || userData.risk_profile,
        balance: data.balance || userData.balance
      };
      
      setUserData(updatedUserData);
      updateLocalStorageUser(updatedUserData);
      setSuccessMessage('Profile updated successfully!');
      
    } catch (error) {
      console.error('Update profile error:', error);
      setError(error.message || 'Failed to update profile');
    }
  };

  const handleAddFunds = async () => {
    if (!addFundsAmount || parseFloat(addFundsAmount) <= 0) {
      setError('Please enter a valid amount');
      return;
    }
    
    setIsAddingFunds(true);
    setError('');
    setSuccessMessage('');
    
    try {
      const token = localStorage.getItem('access_token');
      if (!token) {
        throw new Error('Authentication token not found. Please log in again.');
      }

      const response = await fetch('http://localhost:8000/api/account/add_funds/', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({ amount: addFundsAmount })
      });

      if (response.status === 401) {
        localStorage.removeItem('access_token');
        localStorage.removeItem('user');
        navigate('/login');
        return;
      }

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(
          errorData.error || 
          errorData.message || 
          `Failed to add funds. Status: ${response.status}`
        );
      }

      const data = await response.json();
      setSuccessMessage(data.success);
      setUserData(prev => ({
        ...prev,
        balance: (parseFloat(prev.balance) + parseFloat(addFundsAmount)).toFixed(2)
      }));
      setAddFundsAmount('');
      
    } catch (error) {
      console.error('Add funds error:', error);
      setError(error.message || 'Failed to add funds');
    } finally {
      setIsAddingFunds(false);
    }
  };

  if (isLoading) {
    return (
      <div className="app-container">
        <Sidebar />
        <div className="profile-container">
          <div className="loading-spinner"></div>
          <p>Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="app-container">
      <Sidebar />
      <div className="profile-container">
        <h1>Your Profile</h1>
        
        <div className="profile-header">
          <div className="avatar-placeholder">
            {userData.username ? userData.username.charAt(0).toUpperCase() : 'U'}
          </div>
          <div>
            <h2>{userData.username}</h2>
            <p className="account-type-badge">
              {userData.account_type === 'DEMO' ? 'Demo Account' : 'Live Account'}
            </p>
          </div>
        </div>
        
        {error && <div className="message error">{error}</div>}
        {successMessage && <div className="message success">{successMessage}</div>}
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="username">Username</label>
            <input
              type="text"
              id="username"
              name="username"
              value={userData.username}
              onChange={handleChange}
              className={formErrors.username ? 'error-field' : ''}
              required
            />
            {formErrors.username && <div className="error-text">{formErrors.username}</div>}
          </div>
          
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              name="email"
              value={userData.email}
              onChange={handleChange}
              className={formErrors.email ? 'error-field' : ''}
              required
            />
            {formErrors.email && <div className="error-text">{formErrors.email}</div>}
          </div>
          
          <div className="form-group">
            <label htmlFor="phone">Phone</label>
            <input
              type="tel"
              id="phone"
              name="phone"
              value={userData.phone}
              onChange={handleChange}
              className={formErrors.phone ? 'error-field' : ''}
            />
            {formErrors.phone && <div className="error-text">{formErrors.phone}</div>}
          </div>
          
          <div className="form-group">
            <label htmlFor="account_type">Account Type</label>
            <select
              id="account_type"
              name="account_type"
              value={userData.account_type}
              onChange={handleChange}
            >
              <option value="DEMO">Demo Account</option>
              <option value="LIVE">Live Account</option>
            </select>
          </div>
          
          <div className="form-group">
            <label htmlFor="risk_profile">Risk Profile</label>
            <div className="risk-profile-indicator">
              <div className={`risk-level ${userData.risk_profile.toLowerCase()}`}>
                {userData.risk_profile.charAt(0) + userData.risk_profile.slice(1).toLowerCase()}
              </div>
            </div>
            <select
              id="risk_profile"
              name="risk_profile"
              value={userData.risk_profile}
              onChange={handleChange}
            >
              <option value="LOW">Low Risk</option>
              <option value="MEDIUM">Medium Risk</option>
              <option value="HIGH">High Risk</option>
            </select>
          </div>
          
          <div className="balance-group">
            <div className="balance-header">
              <label>Account Balance</label>
              <span className="balance-actions">
                <button 
                  type="button" 
                  className="btn-add-funds"
                  onClick={() => document.getElementById('addFundsModal').showModal()}
                >
                  Add Funds
                </button>
              </span>
            </div>
            <div className="balance-amount">₹{parseFloat(userData.balance).toFixed(2)}</div>
          </div>
          
          <div className="form-actions">
            <button type="submit" className="btn-update">Update Profile</button>
          </div>
        </form>
        
        <dialog id="addFundsModal" className="modal">
          <div className="modal-content">
            <h3>Add Funds to Your Account</h3>
            <div className="form-group">
              <label htmlFor="amount">Amount (₹)</label>
              <input
                type="number"
                id="amount"
                value={addFundsAmount}
                onChange={(e) => setAddFundsAmount(e.target.value)}
                min="1"
                step="any"
                placeholder="Enter amount"
              />
            </div>
            <div className="modal-actions">
              <button 
                className="btn-cancel"
                onClick={() => document.getElementById('addFundsModal').close()}
              >
                Cancel
              </button>
              <button 
                className="btn-confirm"
                onClick={handleAddFunds}
                disabled={isAddingFunds}
              >
                {isAddingFunds ? 'Processing...' : 'Add Funds'}
              </button>
            </div>
          </div>
        </dialog>
      </div>
    </div>
  );
};

export default ProfilePage;